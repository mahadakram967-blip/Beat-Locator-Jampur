APK banane ka tareeqa (bina Android Studio ke):
1. github.com par free account banayein > New repository (naam: jampur-beat-locator).
2. Is folder ki saari files (www, package.json, capacitor.config.json, .github) repo mein upload karein.
   (.github folder upload hona zaroori hai.)
3. Repo mein "Actions" tab kholein > "Build APK" run hone dein (3-5 minute).
4. Run khatam hone par neeche "Artifacts" se Jampur-Beat-Locator-APK download karein, zip kholein.
5. app-debug.apk phone mein install karein (Unknown sources allow karein).
6. App pehli dafa khulne par Location permission maangegi: "While using the app" > Precise allow karein.
